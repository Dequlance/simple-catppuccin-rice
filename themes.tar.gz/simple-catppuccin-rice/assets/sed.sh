#!/bin/sh
sed -i \
         -e 's/#1e1e2e/rgb(0%,0%,0%)/g' \
         -e 's/#f2cdcd/rgb(100%,100%,100%)/g' \
    -e 's/#313244/rgb(50%,0%,0%)/g' \
     -e 's/#729fcf/rgb(0%,50%,0%)/g' \
     -e 's/#1e1e2e/rgb(50%,0%,50%)/g' \
     -e 's/#f2cdcd/rgb(0%,0%,50%)/g' \
	"$@"
